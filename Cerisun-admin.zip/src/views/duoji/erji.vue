<template>
  <div>
    无限级菜单测试======二级页面
  </div>
</template>

<script>
export default {
  name: 'erji'
}
</script>

<style scoped>

</style>
