<template>
    <div>工单明细</div>
</template>

<script>
export default {
  name: "gongdandetail",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>

<style scoped>
</style>
