<template>
    <div>素材库</div>
</template>

<script>
export default {
  name: "sucai",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>

<style scoped>
</style>
