<template>

</template>
<script>
export default {
  name: "debuglog",
  data() {
    return {}
  }
}
</script>

<style>

</style>

