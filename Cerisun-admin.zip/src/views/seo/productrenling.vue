<template>
    <div>商品认领</div>
</template>

<script>
export default {
  name: "productrenling",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>

<style scoped>
</style>
