<template>
    <div>广告费用导入</div>
</template>

<script>
export default {
  name: "guanggaocost",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>

<style scoped>
</style>
