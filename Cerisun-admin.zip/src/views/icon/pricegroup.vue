<template>
    <div>价格组</div>
</template>

<script>
export default {
  name: "pricegroup",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>

<style scoped>
</style>
